Vercel ready static HTML site

Files:
- index.html
- barber.html
- tattoo.html
- vercel.json

Deploy to Vercel by uploading this folder or connecting a Git repository.
No build command is needed.
Output directory: leave empty / root.

Vercel Web Analytics script has been added to all HTML files.
Enable Web Analytics in your Vercel project dashboard after deployment.
